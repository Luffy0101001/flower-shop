const menuToggle = document.getElementById("menu-toggle");
const navLinks = document.getElementById("nav-links");

menuToggle.addEventListener("click", () => {
  navLinks.classList.toggle("show");
});
// get in the learn mor button
// const lmp1btn = document.getElementById("lmp1btn");
// const showedpr = document.getElementById("showedpr");

// lmp1btn.addEventListener("click", function (e) {
//   e.preventDefault();
//   showedpr.style.display = "block";
// });

// lmp1btn.addEventListener("blur", function (e) {
//   e.preventDefault();
//   showedpr.style.display = "none";
// });
